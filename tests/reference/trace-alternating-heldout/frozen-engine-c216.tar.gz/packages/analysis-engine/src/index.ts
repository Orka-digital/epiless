import { WasmDenseArena, EMBEDDED_KERNEL_BYTES } from './wasm-dense.js';
import type { Finding, FrameQuality } from '@flashguard/core';
import { DiagnosticHistory } from './diagnostic-history.js';
import { ExactSrgbCache, linear } from './color-cache.js';
import type { SpatialEvidence } from '../../core/src/spatial.js';
import {
  balancedCheckerboard,
  combinedMaskFieldAnalysis,
  exactTranslation,
  type VisualFieldCalibration,
} from './spatial.js';
export {
  combinedMaskFieldAnalysis,
  visualFieldFromDisplay,
} from './spatial.js';
export type { MaskFieldAnalysis, VisualFieldCalibration } from './spatial.js';

export const ENGINE_VERSION = '0.4.0-candidate';
// Sub-microsecond floating error must not count both endpoints of a 1 s window.
const WITHIN_ROLLING_SECOND_MS = 1000 - 1e-6;
const LITTLE_ENDIAN_PACKED_RGBA =
  new Uint8Array(new Uint32Array([0x11223344]).buffer)[0] === 0x44;
export interface CapturedFrame {
  rgba: Uint8Array | Uint8ClampedArray;
  width: number;
  height: number;
  timestampMs: number;
  sourceWidth?: number;
  sourceHeight?: number;
}
export interface AnalysisBackendStats {
  backend: 'WASM_DENSE' | 'JS';
  selectionReason: 'READY' | 'FORCED_JS' | 'UNAVAILABLE';
  denseFrames: number;
  inputCopiedBytes: number;
  inputCopyMs: number;
  kernelMs: number;
  wasmMemoryBytes: number;
  migratedStateBytes: number;
  extraStateBytes: number;
  engineStateBytes: number;
  embeddedKernelBytes: number;
}
export interface AnalysisOptions {
  /** AUTO selects the exact WASM dense route when initialization succeeds. */
  backend?: 'AUTO' | 'JS';
  minEffectiveFps?: number;
  maxGapMs?: number;
  maxPixels?: number;
  /** Bounded representative-pixel evidence; disable only for numeric benchmarks. */
  diagnostics?: boolean;
  /** Called once when a new candidate is first observed; never contains frame images. */
  onCandidate?: (finding: Finding) => void;
  /** Explicit source-pixel field: physical calibration or labelled reference geometry. */
  visualField?: VisualFieldCalibration;
}
export interface AnalysisResult {
  status: 'NO_ISSUES_OBSERVED' | 'NEEDS_REVIEW' | 'INCONCLUSIVE';
  passed: null;
  quality: FrameQuality;
  findings: Finding[];
  limitations: string[];
}

export function relativeLuminance(
  red: number,
  green: number,
  blue: number,
): number {
  for (const channel of [red, green, blue]) {
    if (!Number.isInteger(channel) || channel < 0 || channel > 255)
      throw new TypeError('Expected an 8-bit sRGB channel');
  }
  return 0.2126 * linear[red] + 0.7152 * linear[green] + 0.0722 * linear[blue];
}

/** Seven alternating transitions exceed three cycles; half-open windows avoid endpoint double counting. */
class TransitionHistory {
  readonly starts: Uint16Array;
  readonly count: Uint8Array;
  readonly next: Uint8Array;
  readonly active: Uint8Array;
  hasActive = false;
  activeCount = 0;
  earliestActive = Infinity;
  readonly activeSeeds: Uint32Array;
  activeSeedCount = 0;
  firstActive = Infinity;
  lastActive = -1;
  constructor(
    readonly pixels: number,
    private readonly times: Float64Array,
    arena?: WasmDenseArena,
  ) {
    this.starts =
      (arena?.views.gstarts as Uint16Array | undefined) ??
      new Uint16Array(pixels * 7);
    this.count =
      (arena?.views.gcount as Uint8Array | undefined) ?? new Uint8Array(pixels);
    this.next =
      (arena?.views.gnext as Uint8Array | undefined) ?? new Uint8Array(pixels);
    this.active =
      (arena?.views.gactive as Uint8Array | undefined) ??
      new Uint8Array(pixels);
    this.activeSeeds =
      (arena?.views.gseeds as Uint32Array | undefined) ?? new Uint32Array(256);
  }
  transition(pixel: number, frame: number): void {
    this.starts[pixel * 7 + this.next[pixel]] = frame;
    this.next[pixel] = (this.next[pixel] + 1) % 7;
    this.count[pixel] = Math.min(7, this.count[pixel] + 1);
    if (
      this.count[pixel] === 7 &&
      this.times[frame] - this.started(pixel) < WITHIN_ROLLING_SECOND_MS
    ) {
      this.active[pixel] = 1;
      this.hasActive = true;
      if (this.activeSeedCount < this.activeSeeds.length)
        this.activeSeeds[this.activeSeedCount] = pixel;
      this.activeSeedCount++;
    }
  }
  started(pixel: number): number {
    return this.times[this.starts[pixel * 7 + this.next[pixel]]];
  }
}

/** Latest starts of one through three disjoint pairs, plus an opposing continuation. */
class OpposingPairHistory {
  readonly starts: Uint16Array;
  readonly previous: Uint16Array;
  readonly tripleEndingPrevious: Uint16Array;
  readonly candidateStarts: Uint16Array;
  readonly active: Uint8Array;
  hasActive = false;
  activeCount = 0;
  earliestActive = Infinity;
  readonly activeSeeds: Uint32Array;
  activeSeedCount = 0;
  firstActive = Infinity;
  lastActive = -1;
  constructor(
    pixels: number,
    private readonly times: Float64Array,
    arena?: WasmDenseArena,
  ) {
    this.starts =
      (arena?.views.rstarts as Uint16Array | undefined) ??
      new Uint16Array(pixels * 3);
    this.previous =
      (arena?.views.rprevious as Uint16Array | undefined) ??
      new Uint16Array(pixels * 3);
    this.tripleEndingPrevious =
      (arena?.views.rtriple as Uint16Array | undefined) ??
      new Uint16Array(pixels);
    this.candidateStarts =
      (arena?.views.rcandidate as Uint16Array | undefined) ??
      new Uint16Array(pixels);
    this.active =
      (arena?.views.ractive as Uint8Array | undefined) ??
      new Uint8Array(pixels);
    this.activeSeeds =
      (arena?.views.rseeds as Uint32Array | undefined) ?? new Uint32Array(256);
  }
  transition(
    pixel: number,
    started: number,
    ended: number,
    opposing: boolean,
  ): void {
    const offset = pixel * 3;
    const tripleStart = this.tripleEndingPrevious[pixel];
    this.tripleEndingPrevious[pixel] = opposing ? this.previous[offset + 1] : 0;
    if (
      opposing &&
      this.times[ended] - this.times[tripleStart] < WITHIN_ROLLING_SECOND_MS
    ) {
      this.active[pixel] = 1;
      this.hasActive = true;
      if (this.activeSeedCount < this.activeSeeds.length)
        this.activeSeeds[this.activeSeedCount] = pixel;
      this.activeSeedCount++;
      this.candidateStarts[pixel] = tripleStart;
    }
    // A disjoint pair cannot reuse a transition from an earlier pair. Unlike
    // the streaming DP, the regression oracle exhaustively enumerates pairs.
    for (let pairs = 2; pairs >= 0; pairs--) {
      const old = this.starts[offset + pairs];
      if (opposing)
        this.starts[offset + pairs] = Math.max(
          old,
          pairs === 0 ? started : this.previous[offset + pairs - 1],
        );
      this.previous[offset + pairs] = old;
    }
  }
  started(pixel: number): number {
    return this.times[this.candidateStarts[pixel]];
  }
  reset(pixel: number): void {
    this.starts.fill(0, pixel * 3, pixel * 3 + 3);
    this.previous.fill(0, pixel * 3, pixel * 3 + 3);
    this.tripleEndingPrevious[pixel] = 0;
    this.candidateStarts[pixel] = 0;
  }
}

/**
 * Streaming, unvalidated candidate detector for SDR sRGB captures. No frames persisted;
 * bounded pixel state and a volatile diagnostic ring are retained in memory.
 * Counts opposing excursions per pixel, then clusters only pixels active in the same frame.
 * It deliberately makes no normative area, fine-pattern, HDR or WCAG conformity decision.
 */
export class FrameAnalyzer {
  private readonly minFps: number;
  private readonly permittedGap: number;
  private readonly maxPixels: number;
  private readonly diagnosticsEnabled: boolean;
  private readonly onCandidate?: (finding: Finding) => void;
  private readonly visualField?: VisualFieldCalibration;
  // Exact Float64 times are shared by all pixels; per-pixel histories use compact
  // indices, not quantized timestamps. Index zero always means no transition.
  private wasmArena: WasmDenseArena | undefined;
  private backendReason: AnalysisBackendStats['selectionReason'];
  private backendFailed = false;
  private denseFrames = 0;
  private inputCopiedBytes = 0;
  private inputCopyMs = 0;
  private kernelMs = 0;
  private frameTimes: Float64Array = new Float64Array(65536);
  private readonly colors = new ExactSrgbCache();
  private frameIndex = 0;
  private diagnosticHistory: DiagnosticHistory | undefined;
  private width = 0;
  private height = 0;
  private sourceWidth = 0;
  private sourceHeight = 0;
  private count = 0;
  private first = 0;
  private last = 0;
  private gap = 0;
  private downsampled = false;
  private interrupted = false;
  private invalid = false;
  private finalized: AnalysisResult | undefined;
  private readonly notes = new Set<string>();
  private readonly findings: Finding[] = [];
  private mergeFrom = 0;
  private general!: TransitionHistory;
  private red!: OpposingPairHistory;
  private luminance!: Float64Array;
  private direction!: Int8Array;
  private redAnchor!: Uint32Array;
  private saturated!: Uint8Array;
  private redPending!: Uint8Array;
  private redDu!: Float64Array;
  private redDv!: Float64Array;
  private redStart!: Uint16Array;
  private queue!: Int32Array;
  private previousRgb!: Uint32Array;
  private representatives!: Uint32Array;
  private tileUniform!: Uint8Array;
  private tilePeers!: Int32Array;
  private tileDependents!: Uint32Array;
  private tilesPrepared = false;
  private readonly tileCandidates = new Int32Array(4096 * 8);
  private readonly tileCandidateCounts = new Uint8Array(4096);
  private tileColumns = 0;
  private representativeCount = 0;
  private previousFrame: Uint32Array | undefined;
  private currentRgba: Uint8Array | Uint8ClampedArray | undefined;
  private currentMotion: SpatialEvidence['motion'] = {
    kind: 'NONE_DEMONSTRATED',
    automaticallyExcluded: false,
  };
  private stateBytes = 0;

  constructor(options: AnalysisOptions = {}) {
    if (
      options.backend !== undefined &&
      options.backend !== 'AUTO' &&
      options.backend !== 'JS'
    )
      throw new TypeError('Invalid analysis backend');
    this.backendReason = options.backend === 'JS' ? 'FORCED_JS' : 'READY';
    this.diagnosticsEnabled = options.diagnostics !== false;
    this.onCandidate = options.onCandidate;
    this.visualField = options.visualField;
    if (
      options.visualField &&
      (![options.visualField.widthPx, options.visualField.heightPx].every(
        (n) => Number.isInteger(n) && n > 0 && n <= 16384,
      ) ||
        ![
          'EXPLICIT_CALIBRATION',
          'W3C_1024_768_REFERENCE',
          'W3C_CSS_REFERENCE',
        ].includes(options.visualField.basis) ||
        options.visualField.reference.length > 1000 ||
        !options.visualField.reference.length)
    )
      throw new TypeError('Invalid visual-field calibration');
    this.frameTimes[0] = -Infinity;
    this.minFps = options.minEffectiveFps ?? 30;
    this.permittedGap = options.maxGapMs ?? 100;
    this.maxPixels = options.maxPixels ?? 640 * 360;
    if (
      !Number.isFinite(this.minFps) ||
      this.minFps <= 0 ||
      !Number.isFinite(this.permittedGap) ||
      this.permittedGap <= 0 ||
      !Number.isInteger(this.maxPixels) ||
      this.maxPixels < 1 ||
      this.maxPixels > 1920 * 1080
    )
      throw new TypeError('Invalid analysis limits');
  }

  markInterrupted(
    reason = 'Capture was interrupted; unobserved intervals are not assessed.',
  ): void {
    if (this.finalized) throw new Error('Analysis already finalized');
    this.interrupted = true;
    this.notes.add(reason.slice(0, 2000));
    // Do not join transitions across an interruption, even if the next timestamp is close.
    if (this.count) this.resetTemporalState();
  }

  /** Reserve native pixel state before the observation window opens. This does
   * not submit a frame, establish a timestamp, or create diagnostic evidence. */
  prepare(width: number, height: number): void {
    if (this.backendFailed)
      throw new Error(
        'Analysis backend failed; create a new analyzer before accepting frames.',
      );
    if (this.finalized || this.count)
      throw new Error('Analysis has already started');
    if (
      ![width, height].every(
        (n) => Number.isInteger(n) && n > 0 && n <= 16384,
      ) ||
      width * height > this.maxPixels
    )
      throw new TypeError('Invalid preparation dimensions');
    if (this.width !== width || this.height !== height)
      this.allocate(width, height);
  }

  /** Current fixed input allocation; a converter must request it after prepare
   * and again after a geometry change. No temporal state is copied per frame. */
  getInputRgba(): Uint8ClampedArray | undefined {
    return this.wasmArena?.inputRgba;
  }

  /** Cumulative execution counters, with current retained-memory accounting. */
  getBackendStats(): Readonly<AnalysisBackendStats> {
    return Object.freeze({
      backend: this.wasmArena ? 'WASM_DENSE' : 'JS',
      selectionReason: this.backendReason,
      denseFrames: this.denseFrames,
      inputCopiedBytes: this.inputCopiedBytes,
      inputCopyMs: this.inputCopyMs,
      kernelMs: this.kernelMs,
      wasmMemoryBytes: this.wasmArena?.memoryBytes ?? 0,
      migratedStateBytes: this.wasmArena?.migratedStateBytes ?? 0,
      extraStateBytes: this.wasmArena?.extraAllocatedBytes ?? 0,
      engineStateBytes: this.stateBytes,
      embeddedKernelBytes: EMBEDDED_KERNEL_BYTES,
    });
  }

  private allocate(width: number, height: number): void {
    this.width = width;
    this.height = height;
    this.diagnosticHistory = this.diagnosticsEnabled
      ? new DiagnosticHistory(width, height)
      : undefined;
    this.mergeFrom = this.findings.length;
    const size = width * height;
    const previousTimes = this.frameTimes;
    if (this.wasmArena?.width === width && this.wasmArena.height === height) {
      this.wasmArena.reset();
    } else if (this.backendReason === 'READY') {
      try {
        // Budget before allocating the arena. These auxiliary arrays remain in
        // JS; migrated temporal arrays are counted only inside WASM pages.
        const tiles = Math.ceil(width / 8) * Math.ceil(height / 8);
        const auxiliaryBytes =
          this.colors.allocatedBytes +
          size * 8 +
          tiles * 9 +
          this.tileCandidates.byteLength +
          this.tileCandidateCounts.byteLength +
          (this.diagnosticHistory?.allocatedBytes ?? 0) +
          EMBEDDED_KERNEL_BYTES;
        this.wasmArena = new WasmDenseArena(
          width,
          height,
          256 * 1024 * 1024 - auxiliaryBytes,
        );
      } catch (error) {
        if (this.count) {
          this.backendFailed = true;
          this.interrupted = true;
          this.notes.add(
            'WASM state initialization failed after capture started; this frame was not retried.',
          );
          throw error;
        }
        // A pre-observation re-prepare may replace an earlier arena. Do not
        // retain its entire buffer through the timestamp view on JS fallback.
        if (this.wasmArena) this.frameTimes = new Float64Array(previousTimes);
        this.wasmArena = undefined;
        this.backendReason = 'UNAVAILABLE';
      }
    }
    const arena = this.wasmArena;
    if (arena) {
      this.frameTimes = arena.views.times as Float64Array;
      if (previousTimes.buffer !== this.frameTimes.buffer)
        this.frameTimes.set(previousTimes);
    }
    this.representativeCount = size;
    this.frameIndex = 0;
    this.general = new TransitionHistory(size, this.frameTimes, arena);
    this.red = new OpposingPairHistory(size, this.frameTimes, arena);
    this.luminance =
      (arena?.views.luminance as Float64Array | undefined) ??
      new Float64Array(size).fill(NaN);
    this.direction =
      (arena?.views.direction as Int8Array | undefined) ?? new Int8Array(size);
    this.redAnchor =
      (arena?.views.anchor as Uint32Array | undefined) ??
      new Uint32Array(size).fill(0xffffffff);
    this.saturated =
      (arena?.views.saturated as Uint8Array | undefined) ??
      new Uint8Array(size);
    this.redPending =
      (arena?.views.pending as Uint8Array | undefined) ?? new Uint8Array(size);
    this.redDu =
      (arena?.views.du as Float64Array | undefined) ?? new Float64Array(size);
    this.redDv =
      (arena?.views.dv as Float64Array | undefined) ?? new Float64Array(size);
    this.redStart =
      (arena?.views.redstart as Uint16Array | undefined) ??
      new Uint16Array(size);
    this.queue = new Int32Array(size);
    this.previousRgb =
      (arena?.views.previous_rgb as Uint32Array | undefined) ??
      new Uint32Array(size).fill(0xffffffff);
    this.representatives =
      (arena?.views.representatives as Uint32Array | undefined) ??
      new Uint32Array(size);
    for (let pixel = 0; pixel < size; pixel++)
      this.representatives[pixel] = pixel;
    this.tileColumns = Math.ceil(width / 8);
    this.tileUniform = new Uint8Array(this.tileColumns * Math.ceil(height / 8));
    this.tilePeers = new Int32Array(this.tileUniform.length).fill(-1);
    this.tileDependents = new Uint32Array(this.tileUniform.length);
    this.tilesPrepared = false;
    this.tileCandidateCounts.fill(0);
    this.previousFrame = new Uint32Array(size);
    this.stateBytes =
      this.frameTimes.byteLength +
      this.colors.allocatedBytes +
      this.general.starts.byteLength +
      this.general.count.byteLength +
      this.general.next.byteLength +
      this.general.active.byteLength +
      this.general.activeSeeds.byteLength +
      this.red.starts.byteLength +
      this.red.previous.byteLength +
      this.red.tripleEndingPrevious.byteLength +
      this.red.candidateStarts.byteLength +
      this.red.active.byteLength +
      this.red.activeSeeds.byteLength +
      this.luminance.byteLength +
      this.direction.byteLength +
      this.redAnchor.byteLength +
      this.saturated.byteLength +
      this.redPending.byteLength +
      this.redDu.byteLength +
      this.redDv.byteLength +
      this.redStart.byteLength +
      this.queue.byteLength +
      this.previousRgb.byteLength +
      this.representatives.byteLength +
      this.tileUniform.byteLength +
      this.tilePeers.byteLength +
      this.tileDependents.byteLength +
      this.tileCandidates.byteLength +
      this.tileCandidateCounts.byteLength +
      size * 4 +
      (this.diagnosticHistory?.allocatedBytes ?? 0) +
      (arena?.extraAllocatedBytes ?? 0) +
      EMBEDDED_KERNEL_BYTES;
    if (this.stateBytes > 256 * 1024 * 1024)
      throw new Error('Total engine-state budget exceeded');
  }

  /** Lossless state sharing. Pixels share temporal state only while their full
   * observed RGBA histories agree, within uniform tiles or identical tile pairs.
   * Every original source pixel is compared. On divergence,
   * materialize the exact prior state before analysing all original pixels.
   * This is neither downsampling nor rotating/subsampling tile coverage. */
  private prepareTiles(
    rgba: Uint8Array | Uint8ClampedArray,
    changedRuns?: Uint32Array,
  ): void {
    const words =
      rgba.byteOffset % 4 === 0
        ? new Uint32Array(rgba.buffer, rgba.byteOffset, rgba.byteLength / 4)
        : undefined;
    let dirty: Uint8Array | undefined;
    if (changedRuns && changedRuns.length < 192) {
      dirty = new Uint8Array(this.tileUniform.length);
      for (let i = 0; i < changedRuns.length; i += 3) {
        let p = changedRuns[i],
          end = changedRuns[i + 1];
        while (p < end) {
          const row = Math.floor(p / this.width),
            x = p % this.width,
            last = Math.min(this.width - 1, end - 1 - row * this.width);
          for (let tx = x >>> 3; tx <= last >>> 3; tx++)
            dirty[(row >>> 3) * this.tileColumns + tx] = 1;
          p = (row + 1) * this.width;
        }
      }
    }
    for (let ty = 0; ty < this.height; ty += 8) {
      for (let tx = 0; tx < this.width; tx += 8) {
        const tile = (ty >>> 3) * this.tileColumns + (tx >>> 3);
        const peer = this.tilePeers[tile];
        if (dirty && !dirty[tile] && (peer < 0 || !dirty[peer])) continue;
        if (peer >= 0) {
          const seed = ty * this.width + tx;
          const peerSeed =
            Math.floor(peer / this.tileColumns) * 8 * this.width +
            (peer % this.tileColumns) * 8;
          if (words && this.sameTile(words, seed, peerSeed)) {
            if (this.tileUniform[tile] !== this.tileUniform[peer]) {
              this.mapTile(seed, peerSeed);
              this.tileUniform[tile] = this.tileUniform[peer];
            }
          } else {
            // All comparisons/splits precede transition updates, so these are
            // the exact previous histories even when the peer changes too.
            for (let y = 0; y < 8; y++)
              for (let x = 0; x < 8; x++) {
                const pixel = seed + y * this.width + x;
                this.copyPixelState(this.representatives[pixel], pixel);
                this.representatives[pixel] = pixel;
              }
            this.tilePeers[tile] = -1;
            this.tileDependents[peer]--;
            this.representativeCount += 64;
            this.tileUniform[tile] = 2;
          }
          continue;
        }
        if (this.tileUniform[tile] === 2) continue;
        const seed = ty * this.width + tx,
          offset = seed * 4;
        const right = Math.min(tx + 8, this.width),
          bottom = Math.min(ty + 8, this.height);
        let equal = true;
        outer: for (let y = ty; y < bottom; y++)
          for (let x = tx; x < right; x++) {
            const i = (y * this.width + x) * 4;
            if (
              words
                ? words[i / 4] !== words[seed]
                : rgba[i] !== rgba[offset] ||
                  rgba[i + 1] !== rgba[offset + 1] ||
                  rgba[i + 2] !== rgba[offset + 2] ||
                  rgba[i + 3] !== rgba[offset + 3]
            ) {
              equal = false;
              break outer;
            }
          }
        if (equal) {
          if (!this.tileUniform[tile]) {
            this.tileUniform[tile] = 1;
            this.representativeCount -= (right - tx) * (bottom - ty) - 1;
            for (let y = ty; y < bottom; y++)
              this.representatives.fill(
                seed,
                y * this.width + tx,
                y * this.width + right,
              );
          }
        } else {
          const shared = this.tileUniform[tile] === 1;
          this.tileUniform[tile] = 2;
          if (shared)
            this.representativeCount += (right - tx) * (bottom - ty) - 1;
          if (shared)
            for (let y = ty; y < bottom; y++)
              for (let x = tx; x < right; x++) {
                const pixel = y * this.width + x;
                this.representatives[pixel] = pixel;
                if (pixel !== seed) this.copyPixelState(seed, pixel);
              }
        }
      }
    }
    if (!this.tilesPrepared && words) this.shareInitialTiles(words);
    this.tilesPrepared = true;
  }

  private sameTile(words: Uint32Array, first: number, second: number): boolean {
    for (let y = 0; y < 8; y++)
      for (let x = 0; x < 8; x++)
        if (
          words[first + y * this.width + x] !==
          words[second + y * this.width + x]
        )
          return false;
    return true;
  }

  private mapTile(seed: number, peerSeed: number): void {
    for (let y = 0; y < 8; y++)
      for (let x = 0; x < 8; x++)
        this.representatives[seed + y * this.width + x] =
          this.representatives[peerSeed + y * this.width + x];
  }

  private shareInitialTiles(words: Uint32Array): void {
    // Hashes only select candidates. All 64 RGBA pixels must match exactly.
    // At most eight canonical candidates per hash bound collision work; an
    // unshared tile retains full per-pixel processing. No later re-coalescing.
    for (let ty = 0; ty + 8 <= this.height; ty += 8)
      for (let tx = 0; tx + 8 <= this.width; tx += 8) {
        const seed = ty * this.width + tx,
          tile = (ty >>> 3) * this.tileColumns + (tx >>> 3);
        let hash = 2166136261;
        for (let y = 0; y < 8; y++)
          for (let x = 0; x < 8; x++)
            hash = Math.imul(hash ^ words[seed + y * this.width + x], 16777619);
        const bucket = (hash ^ (hash >>> 16)) & 4095;
        const count = this.tileCandidateCounts[bucket];
        let peer = -1;
        for (let index = 0; index < count; index++) {
          const candidate = this.tileCandidates[bucket * 8 + index];
          const peerSeed =
            Math.floor(candidate / this.tileColumns) * 8 * this.width +
            (candidate % this.tileColumns) * 8;
          if (this.sameTile(words, seed, peerSeed)) {
            peer = candidate;
            this.mapTile(seed, peerSeed);
            break;
          }
        }
        if (peer >= 0) {
          this.representativeCount -= this.tileUniform[tile] === 1 ? 1 : 64;
          this.tilePeers[tile] = peer;
          this.tileDependents[peer]++;
          this.tileUniform[tile] = this.tileUniform[peer];
        } else if (count < 8) {
          this.tileCandidates[bucket * 8 + count] = tile;
          this.tileCandidateCounts[bucket]++;
        }
      }
  }

  private copyPixelState(from: number, to: number): void {
    for (let i = 0; i < 7; i++)
      this.general.starts[to * 7 + i] = this.general.starts[from * 7 + i];
    this.general.count[to] = this.general.count[from];
    this.general.next[to] = this.general.next[from];
    for (let i = 0; i < 3; i++) {
      this.red.starts[to * 3 + i] = this.red.starts[from * 3 + i];
      this.red.previous[to * 3 + i] = this.red.previous[from * 3 + i];
    }
    this.red.tripleEndingPrevious[to] = this.red.tripleEndingPrevious[from];
    this.red.candidateStarts[to] = this.red.candidateStarts[from];
    this.luminance[to] = this.luminance[from];
    this.direction[to] = this.direction[from];
    this.redAnchor[to] = this.redAnchor[from];
    this.saturated[to] = this.saturated[from];
    this.redPending[to] = this.redPending[from];
    this.redDu[to] = this.redDu[from];
    this.redDv[to] = this.redDv[from];
    this.redStart[to] = this.redStart[from];
    this.previousRgb[to] = this.previousRgb[from];
  }

  private expandActiveTiles(
    history: TransitionHistory | OpposingPairHistory,
  ): void {
    if (!history.hasActive) return;
    history.activeCount = 0;
    history.earliestActive = Infinity;
    history.firstActive = Infinity;
    history.lastActive = -1;
    if (this.representativeCount === 1) {
      // Every source pixel has the exact history of pixel zero. A qualifying
      // representative therefore means an exact full active mask, not a box
      // approximation or a count inferred from the current colour alone.
      history.active.fill(1);
      history.activeCount = this.width * this.height;
      history.firstActive = 0;
      history.lastActive = history.activeCount - 1;
      history.earliestActive = history.started(0);
      return;
    }
    let independent = history.activeSeedCount <= history.activeSeeds.length;
    for (
      let index = 0;
      independent && index < history.activeSeedCount;
      index++
    ) {
      const pixel = history.activeSeeds[index],
        tile =
          (Math.floor(pixel / this.width) >>> 3) * this.tileColumns +
          ((pixel % this.width) >>> 3);
      independent =
        this.tileUniform[tile] === 2 && this.tileDependents[tile] === 0;
    }
    if (independent) {
      // Every active representative has exactly one source pixel. There are no
      // aliases to expand; do not scan two million unrelated pixels for one dot.
      history.activeCount = history.activeSeedCount;
      for (let index = 0; index < history.activeSeedCount; index++) {
        const pixel = history.activeSeeds[index];
        history.firstActive = Math.min(history.firstActive, pixel);
        history.lastActive = Math.max(history.lastActive, pixel);
        history.earliestActive = Math.min(
          history.earliestActive,
          history.started(pixel),
        );
      }
      return;
    }
    for (let pixel = 0; pixel < this.width * this.height; pixel++) {
      if (this.representatives[pixel] !== pixel)
        history.active[pixel] = history.active[this.representatives[pixel]];
      if (history.active[pixel]) {
        if (!history.activeCount) history.firstActive = pixel;
        history.lastActive = pixel;
        history.activeCount++;
        if (this.representatives[pixel] === pixel)
          history.earliestActive = Math.min(
            history.earliestActive,
            history.started(pixel),
          );
      }
    }
  }

  private resetTemporalState(): void {
    this.allocate(this.width, this.height);
  }

  pushFrame(frame: CapturedFrame): void {
    if (this.backendFailed)
      throw new Error(
        'Analysis backend failed; create a new analyzer before accepting frames.',
      );
    if (this.finalized) throw new Error('Analysis already finalized');
    const { rgba, width, height, timestampMs } = frame;
    const sourceWidth = frame.sourceWidth ?? width;
    const sourceHeight = frame.sourceHeight ?? height;
    if (
      !Number.isInteger(width) ||
      !Number.isInteger(height) ||
      width < 1 ||
      height < 1 ||
      width > 16384 ||
      height > 16384 ||
      !Number.isInteger(sourceWidth) ||
      !Number.isInteger(sourceHeight) ||
      sourceWidth < 1 ||
      sourceHeight < 1 ||
      sourceWidth > 16384 ||
      sourceHeight > 16384 ||
      width * height > this.maxPixels ||
      !(rgba instanceof Uint8Array || rgba instanceof Uint8ClampedArray) ||
      rgba.length !== width * height * 4 ||
      !Number.isFinite(timestampMs) ||
      timestampMs < 0
    ) {
      this.invalid = true;
      this.notes.add(
        'A malformed or oversized frame was rejected. Capture quality is insufficient.',
      );
      if (this.count) this.resetTemporalState();
      return;
    }
    if (this.count && timestampMs <= this.last) {
      this.invalid = true;
      this.notes.add(
        'Capture timestamps were not strictly increasing. Rejected frames were not analyzed.',
      );
      this.resetTemporalState();
      return;
    }
    const relativeTime = this.count ? timestampMs - this.first : 0;
    if (!this.count) {
      this.first = timestampMs;
      if (this.width !== width || this.height !== height)
        this.allocate(width, height);
    } else {
      const gap = timestampMs - this.last;
      this.gap = Math.max(this.gap, gap);
      if (width !== this.width || height !== this.height) {
        this.interrupted = true;
        this.notes.add(
          'Capture dimensions changed; no transitions were joined across the scale change.',
        );
        this.allocate(width, height);
      } else if (
        sourceWidth !== this.sourceWidth ||
        sourceHeight !== this.sourceHeight
      ) {
        this.interrupted = true;
        this.notes.add(
          'Source dimensions changed; no transitions were joined across the viewport change.',
        );
        this.resetTemporalState();
      } else if (gap > this.permittedGap) this.resetTemporalState();
    }
    this.sourceWidth = sourceWidth;
    this.sourceHeight = sourceHeight;
    if (
      (frame.sourceWidth !== undefined && frame.sourceWidth !== width) ||
      (frame.sourceHeight !== undefined && frame.sourceHeight !== height)
    ) {
      this.downsampled = true;
      this.notes.add(
        'Capture was rescaled. Small flashing regions may have been lost and area is not validated.',
      );
    }
    this.last = timestampMs;
    this.count++;
    if (this.frameIndex === 65535) {
      this.interrupted = true;
      this.notes.add(
        'The bounded 65,535-frame temporal epoch ended; histories were reset without joining transitions across the boundary.',
      );
      this.resetTemporalState();
    }
    this.frameTimes[++this.frameIndex] = relativeTime;
    this.diagnosticHistory?.push(rgba, relativeTime, this.previousFrame);
    // An actual decoded frame with identical RGBA adds real cadence and trace
    // evidence but cannot create a transition. This is not synthetic sampling.
    if (this.diagnosticHistory && !this.diagnosticHistory.changed) return;
    this.general.active.fill(0);
    this.red.active.fill(0);
    this.general.hasActive = false;
    this.red.hasActive = false;
    this.general.activeSeedCount = this.red.activeSeedCount = 0;
    const changedRuns = this.diagnosticHistory?.changedRuns;
    this.prepareTiles(rgba, changedRuns);
    if (
      changedRuns === undefined &&
      (this.representativeCount === width * height ||
        (this.wasmArena && this.representativeCount > (width * height) / 2)) &&
      LITTLE_ENDIAN_PACKED_RGBA &&
      rgba.byteOffset % 4 === 0
    ) {
      this.processDensePacked(
        new Uint32Array(rgba.buffer, rgba.byteOffset, rgba.byteLength / 4),
      );
    } else {
      let run = 0;
      for (let pixel = changedRuns?.[0] ?? 0; pixel < width * height; pixel++) {
        if (changedRuns) {
          while (run < changedRuns.length && pixel >= changedRuns[run + 1]) {
            run += 3;
            pixel = changedRuns[run] ?? width * height;
          }
          if (pixel >= width * height) break;
        }
        if (this.representatives[pixel] !== pixel) continue;
        const offset = pixel * 4;
        if (rgba[offset + 3] !== 255) {
          this.invalid = true;
          this.notes.add(
            'Non-opaque capture pixels are unsupported; the composited background is unknown.',
          );
          this.luminance[pixel] = NaN;
          this.redAnchor[pixel] = 0xffffffff;
          this.direction[pixel] = 0;
          this.redPending[pixel] = 0;
          this.previousRgb[pixel] = 0xffffffff;
          this.general.count[pixel] = 0;
          this.red.reset(pixel);
          continue;
        }
        const rgb =
          rgba[offset] | (rgba[offset + 1] << 8) | (rgba[offset + 2] << 16);
        // Identical opaque pixels cannot introduce a transition. Temporal histories
        // retain real timestamps; their window is checked on the next complete pair.
        if (this.previousRgb[pixel] === rgb) continue;
        this.previousRgb[pixel] = rgb;
        const r = linear[rgb & 255],
          g = linear[(rgb >>> 8) & 255],
          b = linear[(rgb >>> 16) & 255];
        this.generalTransition(
          pixel,
          0.2126 * r + 0.7152 * g + 0.0722 * b,
          this.frameIndex,
        );
        if (rgb === 0) {
          this.redAnchor[pixel] = 0xffffffff;
          this.redPending[pixel] = 0;
          this.red.reset(pixel);
        } else {
          const saturated = r / (r + g + b) >= 0.8;
          if (this.redAnchor[pixel] === 0xffffffff) {
            this.redAnchor[pixel] = rgb;
            this.saturated[pixel] = saturated ? 1 : 0;
          } else if (saturated || this.saturated[pixel]) {
            const color = this.colors.slot(rgb);
            this.redTransition(pixel, rgb, color, this.frameIndex);
          }
        }
      }
    }
    this.expandActiveTiles(this.general);
    this.expandActiveTiles(this.red);
    this.currentRgba = rgba;
    this.currentMotion =
      this.general.hasActive || this.red.hasActive
        ? exactTranslation(rgba, this.previousFrame, width, height, changedRuns)
        : { kind: 'NONE_DEMONSTRATED', automaticallyExcluded: false };
    this.cluster(this.general, 'GENERAL_FLASH', relativeTime);
    this.cluster(this.red, 'RED_FLASH', relativeTime);
    if (rgba.byteOffset % 4 === 0) {
      this.previousFrame ??= new Uint32Array(width * height);
      this.previousFrame.set(
        new Uint32Array(rgba.buffer, rgba.byteOffset, rgba.byteLength / 4),
      );
    } else this.previousFrame = undefined;
    this.currentRgba = undefined;
  }

  /** Exact dense native route; geometry, diagnostics and frame clocks stay in pushFrame. */
  private processDensePacked(words: Uint32Array): void {
    const arena = this.wasmArena;
    if (!arena) return this.processDenseJavaScript(words);
    let out: Uint32Array;
    try {
      out = arena.process(words, this.frameIndex);
    } catch (error) {
      this.backendFailed = true;
      this.markInterrupted(
        'WASM dense kernel failed; partially updated state was reset, never retried on the same frame.',
      );
      throw error;
    }
    this.denseFrames++;
    this.inputCopiedBytes += arena.lastTiming.copiedInputBytes;
    this.inputCopyMs += arena.lastTiming.inputCopyMs;
    this.kernelMs += arena.lastTiming.kernelMs;
    this.general.activeSeedCount = out[0];
    this.general.hasActive = out[0] > 0;
    this.red.activeSeedCount = out[1];
    this.red.hasActive = out[1] > 0;
    if (out[2]) {
      this.invalid = true;
      this.notes.add(
        'Non-opaque capture pixels are unsupported; the composited background is unknown.',
      );
    }
  }

  private processDenseJavaScript(words: Uint32Array): void {
    for (let pixel = 0; pixel < words.length; pixel++) {
      const word = words[pixel];
      if (word >>> 24 !== 255) {
        this.invalid = true;
        this.notes.add(
          'Non-opaque capture pixels are unsupported; the composited background is unknown.',
        );
        this.luminance[pixel] = NaN;
        this.redAnchor[pixel] = 0xffffffff;
        this.direction[pixel] = 0;
        this.redPending[pixel] = 0;
        this.previousRgb[pixel] = 0xffffffff;
        this.general.count[pixel] = 0;
        this.red.reset(pixel);
        continue;
      }
      const rgb = word & 0xffffff;
      if (this.previousRgb[pixel] === rgb) continue;
      this.previousRgb[pixel] = rgb;
      const r = linear[rgb & 255],
        g = linear[(rgb >>> 8) & 255],
        b = linear[(rgb >>> 16) & 255];
      this.generalTransition(
        pixel,
        0.2126 * r + 0.7152 * g + 0.0722 * b,
        this.frameIndex,
      );
      if (rgb === 0) {
        this.redAnchor[pixel] = 0xffffffff;
        this.redPending[pixel] = 0;
        this.red.reset(pixel);
      } else {
        const saturated = r / (r + g + b) >= 0.8;
        if (this.redAnchor[pixel] === 0xffffffff) {
          this.redAnchor[pixel] = rgb;
          this.saturated[pixel] = saturated ? 1 : 0;
        } else if (saturated || this.saturated[pixel]) {
          const color = this.colors.slot(rgb);
          this.redTransition(pixel, rgb, color, this.frameIndex);
        }
      }
    }
  }

  private generalTransition(
    pixel: number,
    current: number,
    timestamp: number,
  ): void {
    const anchor = this.luminance[pixel];
    if (!Number.isFinite(anchor)) {
      this.luminance[pixel] = current;
      return;
    }
    const delta = current - anchor;
    const direction = this.direction[pixel];
    if (direction && Math.sign(delta) === direction) {
      this.luminance[pixel] = current; // Track the extremum, including gradual excursions.
      return;
    }
    if (
      Math.abs(delta) + Number.EPSILON < 0.1 ||
      Math.min(current, anchor) >= 0.8
    )
      return;
    this.general.transition(pixel, timestamp);
    this.direction[pixel] = delta > 0 ? 1 : -1;
    this.luminance[pixel] = current;
  }

  private redTransition(
    pixel: number,
    rgb: number,
    color: number,
    timestamp: number,
  ): void {
    const saturated = !!(this.colors.flags[color] & 1);
    const anchor = this.redAnchor[pixel];
    if (anchor === 0xffffffff) {
      this.redAnchor[pixel] = rgb;
      this.saturated[pixel] = saturated ? 1 : 0;
      return;
    }
    if (!(saturated || this.saturated[pixel])) return;
    this.colors.chromaticity(color, rgb);
    // Read current values before looking up the anchor: colliding full-RGB tags
    // may intentionally reuse the same cache slot.
    const u = this.colors.u[color],
      v = this.colors.v[color];
    const previousColor = this.colors.slot(anchor);
    this.colors.chromaticity(previousColor, anchor);
    const du = u - this.colors.u[previousColor];
    const dv = v - this.colors.v[previousColor];
    if (du * du + dv * dv <= 0.2 ** 2) return;
    this.red.transition(
      pixel,
      this.redStart[pixel],
      timestamp,
      this.redPending[pixel] !== 0 &&
        du * this.redDu[pixel] + dv * this.redDv[pixel] < 0,
    );
    this.redPending[pixel] = 1;
    this.redDu[pixel] = du;
    this.redDv[pixel] = dv;
    this.redStart[pixel] = timestamp;
    this.redAnchor[pixel] = rgb;
    this.saturated[pixel] = saturated ? 1 : 0;
  }

  private cluster(
    history: TransitionHistory | OpposingPairHistory,
    type: Finding['type'],
    ended: number,
  ): void {
    if (!history.hasActive) return;
    const pixels = this.width * this.height;
    const fullMask = history.activeCount === pixels;
    const calibration = !this.downsampled ? this.visualField : undefined;
    const fullFieldPixels = calibration
      ? Math.min(this.width, calibration.widthPx) *
        Math.min(this.height, calibration.heightPx)
      : 0;
    const area = calibration
      ? fullMask
        ? {
            // The exact active count already proves every source pixel is one.
            // Every maximal overlap ties; retain the generic solver's first
            // window and full field denominator, including outside the image.
            totalPixels: pixels,
            maximumPixels: fullFieldPixels,
            fieldWidth: calibration.widthPx,
            fieldHeight: calibration.heightPx,
            maximumRatio:
              fullFieldPixels / (calibration.widthPx * calibration.heightPx),
            thresholdRatio: 0.25 as const,
            exceedsThreshold:
              fullFieldPixels * 4 > calibration.widthPx * calibration.heightPx,
            window: {
              x: 0,
              y: 0,
              width: calibration.widthPx,
              height: calibration.heightPx,
            },
          }
        : combinedMaskFieldAnalysis(
            history.active,
            this.width,
            this.height,
            calibration.widthPx,
            calibration.heightPx,
          )
      : undefined;
    for (let seed = history.firstActive; seed <= history.lastActive; seed++) {
      if (!history.active[seed]) continue;
      let head = 0;
      let tail = 1;
      let minX = this.width,
        minY = this.height,
        maxX = 0,
        maxY = 0,
        started = ended;
      this.queue[0] = seed;
      history.active[seed] = 0;
      if (fullMask) {
        // A homogeneous/full active mask is one exact connected component.
        // Avoid a multi-million-element flood fill on the most severe case.
        head = tail = pixels;
        minX = minY = 0;
        maxX = this.width - 1;
        maxY = this.height - 1;
        started = history.earliestActive;
        history.active.fill(0);
      }
      while (head < tail) {
        const pixel = this.queue[head++];
        const x = pixel % this.width;
        const y = Math.floor(pixel / this.width);
        minX = Math.min(minX, x);
        minY = Math.min(minY, y);
        maxX = Math.max(maxX, x);
        maxY = Math.max(maxY, y);
        started = Math.min(
          started,
          history.started(this.representatives[pixel]),
        );
        // Keep this allocation-free: a closure per native pixel made a full-HD
        // candidate pause the worker for hundreds of milliseconds.
        if (x > 0 && history.active[pixel - 1]) {
          history.active[pixel - 1] = 0;
          this.queue[tail++] = pixel - 1;
        }
        if (x + 1 < this.width && history.active[pixel + 1]) {
          history.active[pixel + 1] = 0;
          this.queue[tail++] = pixel + 1;
        }
        if (y > 0 && history.active[pixel - this.width]) {
          history.active[pixel - this.width] = 0;
          this.queue[tail++] = pixel - this.width;
        }
        if (y + 1 < this.height && history.active[pixel + this.width]) {
          history.active[pixel + this.width] = 0;
          this.queue[tail++] = pixel + this.width;
        }
      }
      const region = {
        x: minX,
        y: minY,
        width: maxX - minX + 1,
        height: maxY - minY + 1,
      };
      const existing = this.findings.find(
        (finding, index) =>
          index >= this.mergeFrom &&
          finding.type === type &&
          ended - finding.endMs <= 1000 &&
          finding.region?.x === minX &&
          finding.region?.y === minY &&
          finding.region.width === region.width &&
          finding.region.height === region.height,
      );
      const previousSpatial = existing?.spatial;
      const currentMaximum = area?.maximumPixels ?? history.activeCount;
      const previousMaximum = previousSpatial
        ? (previousSpatial.visualField?.maximumPixels ??
          previousSpatial.simultaneousPixels)
        : -1;
      const retainSpatial =
        (existing !== undefined || this.findings.length < 100) &&
        (!previousSpatial ||
          currentMaximum > previousMaximum ||
          (currentMaximum === previousMaximum &&
            (history.activeCount > previousSpatial.simultaneousPixels ||
              (history.activeCount === previousSpatial.simultaneousPixels &&
                tail > previousSpatial.componentPixels))));
      // Keep one actual strongest spatial witness, with its own time. The
      // diagnostic trace and live source event still describe first detection.
      const spatial: SpatialEvidence | undefined = retainSpatial
        ? {
            version: 1,
            coordinateSpace: 'ANALYSIS_PIXELS',
            analysisWidth: this.width,
            analysisHeight: this.height,
            sampledAtMs: ended,
            componentPixels: tail,
            simultaneousPixels: history.activeCount,
            simultaneousRatio: history.activeCount / pixels,
            maskBasis: 'QUALIFYING_TRANSITIONS_SAME_FRAME',
            ...(area && calibration
              ? {
                  visualField: {
                    ...calibration,
                    maximumPixels: area.maximumPixels,
                    maximumRatio: area.maximumRatio,
                    thresholdRatio: area.thresholdRatio,
                    exceedsThreshold: area.exceedsThreshold,
                    window: area.window,
                  },
                }
              : {}),
            pattern:
              tail === region.width * region.height && this.currentRgba
                ? balancedCheckerboard(
                    this.currentRgba,
                    this.width,
                    region,
                    calibration,
                  )
                : { kind: 'NONE_DEMONSTRATED', automaticallyExcluded: false },
            motion: this.currentMotion,
          }
        : undefined;
      if (existing) {
        if (spatial) existing.spatial = spatial;
        existing.endMs = ended;
        existing.affectedRatio = Math.max(
          existing.affectedRatio,
          tail / pixels,
        );
      } else if (this.findings.length < 100) {
        const finding: Finding = {
          id: `candidate-${this.findings.length + 1}`,
          type,
          severity: 'warning',
          reviewStatus: 'NEEDS_REVIEW',
          startMs: started,
          endMs: ended,
          flashesInWindow: 3.5,
          qualifyingTransitions: 7,
          affectedRatio: tail / pixels,
          region,
          spatial: spatial!,
          ...(this.diagnosticHistory
            ? {
                diagnostic: this.diagnosticHistory.evidence(
                  seed,
                  history.started(this.representatives[seed]),
                  ended,
                  this.sourceWidth,
                  this.sourceHeight,
                ),
              }
            : {}),
          message: `At least seven qualifying ${type === 'RED_FLASH' ? 'saturated-red chromaticity' : 'luminance'} transitions (three opposing pairs and a continuation) within a rolling second in this region. Candidate only; area and normative conditions require review.`,
        };
        this.findings.push(finding);
        this.onCandidate?.(structuredClone(finding));
      } else
        this.notes.add(
          'The 100-candidate reporting limit was reached; additional candidates are omitted.',
        );
      // A full mask has exactly one component. The mask is already cleared;
      // scanning the remaining zeroes cannot discover another component.
      if (fullMask) break;
    }
  }

  finish(): AnalysisResult {
    if (this.finalized) return structuredClone(this.finalized);
    const duration = this.last - this.first;
    const fps =
      this.count > 1 && duration > 0 ? ((this.count - 1) * 1000) / duration : 0;
    const insufficient =
      this.invalid ||
      this.interrupted ||
      this.downsampled ||
      this.count < 2 ||
      duration < 1000 ||
      fps < this.minFps ||
      this.gap > this.permittedGap;
    if (duration < 1000)
      this.notes.add('Less than one second of usable capture was observed.');
    if (fps < this.minFps)
      this.notes.add(
        `Effective sampling was below ${this.minFps} fps; fast flashes may be missed.`,
      );
    if (this.gap > this.permittedGap)
      this.notes.add(
        `Capture gaps exceeded ${this.permittedGap} ms; transitions across gaps were discarded.`,
      );
    this.notes.add(
      'Unvalidated candidate engine: no WCAG PASS or NON_CONFORMANT verdict. SDR sRGB is assumed; HDR and colour-management accuracy are not validated.',
    );
    this.notes.add(
      'Reported area is a measured pixel ratio, not the WCAG visual-field threshold. Fine patterns, DOM attribution and red black-point chromaticity are not validated.',
    );
    this.finalized = {
      status: insufficient
        ? 'INCONCLUSIVE'
        : this.findings.length
          ? 'NEEDS_REVIEW'
          : 'NO_ISSUES_OBSERVED',
      passed: null,
      quality: {
        frameCount: this.count,
        effectiveFps: fps,
        maxGapMs: this.gap,
        width: this.width,
        height: this.height,
        downsampled: this.downsampled,
        interrupted: this.interrupted,
        ...(this.count
          ? {
              spatial: {
                mode: this.downsampled
                  ? ('RESCALED_PIXELS' as const)
                  : ('NATIVE_PIXELS' as const),
                sourceWidth: this.sourceWidth,
                sourceHeight: this.sourceHeight,
                retainedResolutionRatio: Math.min(
                  1,
                  (this.width * this.height) /
                    (this.sourceWidth * this.sourceHeight),
                ),
                stateBytes: this.stateBytes,
                stateBudgetBytes: 268435456 as const,
                tileSharing: 'LOSSLESS_IDENTICAL_HISTORY' as const,
                colorAssumption: 'SDR_SRGB_8BIT' as const,
              },
            }
          : {}),
      },
      findings: structuredClone(this.findings),
      limitations: [...this.notes],
    };
    // Final reports retain numeric evidence only; release volatile frame buffers.
    this.diagnosticHistory = undefined;
    return structuredClone(this.finalized);
  }
}
